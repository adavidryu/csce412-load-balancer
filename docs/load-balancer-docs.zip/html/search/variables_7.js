var searchData=
[
  ['nextrequestid_0',['nextRequestId',['../LoadBalancer_8cpp.html#aa30964dc1ec9b09ed9f1f33002eb526b',1,'LoadBalancer.cpp']]],
  ['numcompletedrequests_1',['numCompletedRequests',['../structWebServer.html#af29f07306488ddeca4626ee9d9415400',1,'WebServer']]]
];
