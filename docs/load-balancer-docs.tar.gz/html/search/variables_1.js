var searchData=
[
  ['blockedranges_0',['blockedRanges',['../classFirewall.html#a97fec48d43f1471e4256a93bfc7043df',1,'Firewall']]]
];
