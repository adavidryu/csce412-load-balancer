var searchData=
[
  ['dispatchrequeststoidleservers_0',['dispatchRequestsToIdleServers',['../structLoadBalancer.html#ac96ac060d07edfd8a74811dd0297ad6b',1,'LoadBalancer']]]
];
