var searchData=
[
  ['remainingticks_0',['remainingTicks',['../structWebServer.html#a80a831a0eb1772ee248e647876b06f92',1,'WebServer']]],
  ['requestsaddedthistick_1',['requestsAddedThisTick',['../structLoadBalancer.html#ac40781dc2e3cc6bbc2d226e6ff0afa78',1,'LoadBalancer']]],
  ['requestsblockedthistick_2',['requestsBlockedThisTick',['../structLoadBalancer.html#afcd4b6768fddacc6c45085a8bc382e0a',1,'LoadBalancer']]]
];
