var searchData=
[
  ['id_0',['id',['../structRequest.html#a026538b5d27774177b27d0552d25fa13',1,'Request']]],
  ['ipin_1',['ipIn',['../structRequest.html#aa83b5e8331e7f13fb5742984f955d0c1',1,'Request']]],
  ['ipout_2',['ipOut',['../structRequest.html#af585c7ba4ed14c760cf8d72b232091b4',1,'Request']]],
  ['isbusy_3',['isBusy',['../structWebServer.html#af3b6bd2cad6d8d476bc81bb6607eb75f',1,'WebServer']]]
];
