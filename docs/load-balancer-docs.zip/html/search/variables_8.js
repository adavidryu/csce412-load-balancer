var searchData=
[
  ['processinginqueue_0',['processingInQueue',['../structLoadBalancer.html#a84bfdf4d897a80a84c8a07ddafb99379',1,'LoadBalancer']]],
  ['processtime_1',['processTime',['../structRequest.html#a3942c106263c684eb82400e2174a5e53',1,'Request']]]
];
