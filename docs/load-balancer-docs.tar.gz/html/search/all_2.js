var searchData=
[
  ['cooldown_0',['cooldown',['../structLoadBalancer.html#ab70d7bdd6b287c5c827e384eeb11140d',1,'LoadBalancer']]],
  ['currentrequest_1',['currentRequest',['../structWebServer.html#a3569aaaa5858a157d5b1b46e49d0d77f',1,'WebServer']]],
  ['currenttick_2',['currentTick',['../structLoadBalancer.html#ae21f1dc1a222fbd1b5c62f1740649ae6',1,'LoadBalancer']]]
];
